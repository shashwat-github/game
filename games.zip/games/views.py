from django.shortcuts import render

# Create your views here.


def games(request):
    return render(request, 'games.html')


def rubix(request):
    return render(request, 'rubix.html')


def chess(request):
    return render(request, 'chess.html')


def coloron(request):
    return render(request, 'coloron.html')


def pressme(request):
    return render(request, 'pressme.html')


def maze(request):
    return render(request, 'maze.html')


def fly(request):
    return render(request, 'fly.html')


def rabbit(request):
    return render(request, 'rabbit.html')


def crossword(request):
    return render(request, 'crossword.html')
