from django.urls import path
from . import views

urlpatterns = [
    path('', views.games, name='games'),
    path('rubix', views.rubix, name='rubix'),
    path('chess', views.chess, name='chess'),
    path('coloron', views.coloron, name='coloron'),
    path('fly', views.fly, name='fly'),
    path('pressme', views.pressme, name='pressme'),
    path('crossword', views.crossword, name='crossword'),
    path('maze', views.maze, name='maze'),
    path('rabbit', views.rabbit, name='rabbit'),

]
